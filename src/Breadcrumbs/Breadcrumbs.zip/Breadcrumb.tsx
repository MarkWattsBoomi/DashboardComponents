import React = require('react');
import { BreadcrumbEvent } from './BreadcrumbEvent';

export default class Breadcrumb extends React.Component<any, any> {

    constructor(props: any) {
        super(props);
        this.gotoBreadcrumb = this.gotoBreadcrumb.bind(this);
    }

    async gotoBreadcrumb() {
        await this.props.parent.gotoBreadcrumb(this.props.breadcrumb);
    }

    render() {
        const date: Date = new Date((this.props.breadcrumb as BreadcrumbEvent).eventTime);
        return (
            <a
                className="breadcrumb"
                onClick={this.gotoBreadcrumb}
                title={date.toLocaleString()}
            >
                {(this.props.breadcrumb as BreadcrumbEvent).pageElementName}
            </a>
        );
    }
}
