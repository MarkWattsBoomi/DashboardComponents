import React = require('react');

export default class BreadcrumbSpacer extends React.Component<any, any> {

    render() {

        return (
            <span
                className="breadcrumb-spacer"
            >
                ->
            </span>
        );
    }
}
